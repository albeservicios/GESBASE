importScripts("https://www.gstatic.com/firebasejs/12.18.0/firebase-app-compat.js");
importScripts("https://www.gstatic.com/firebasejs/12.18.0/firebase-messaging-compat.js");

/*
 * IMPORTANTE:
 * Reemplazá estos valores por los mismos de Js/firebase-config.js.
 */
firebase.initializeApp({
  apiKey: "PEGAR_API_KEY",
  authDomain: "PEGAR_AUTH_DOMAIN",
  projectId: "PEGAR_PROJECT_ID",
  storageBucket: "PEGAR_STORAGE_BUCKET",
  messagingSenderId: "PEGAR_MESSAGING_SENDER_ID",
  appId: "PEGAR_APP_ID"
});

const messaging = firebase.messaging();

messaging.onBackgroundMessage(payload => {
  const title = payload.notification?.title || "GESBASE";
  const options = {
    body: payload.notification?.body || "Tenés una nueva notificación",
    icon: "/GESBASE-WEB/icon-192.png",
    badge: "/GESBASE-WEB/icon-192.png",
    data: payload.data || {}
  };
  self.registration.showNotification(title, options);
});

self.addEventListener("notificationclick", event => {
  event.notification.close();
  const data = event.notification.data || {};
  const url = data.url || "/GESBASE-WEB/comunicacion.html";
  event.waitUntil(clients.openWindow(url));
});
