GESBASE - COMUNICACION
======================

PRIMERA ETAPA INCLUIDA
1. Chat privado empleado <-> empleado.
2. Los contactos se filtran por empresaId.
3. Solo aparecen empleados con acceso (authUid).
4. Notificaciones web mediante Firebase Cloud Messaging.
5. Service Worker para notificaciones en segundo plano.
6. Estructura preparada para llamadas de audio, video y reuniones grupales.

ARCHIVOS
--------
comunicacion.html
firebase-messaging-sw.js
functions-comunicacion.js
sonidos/LEEME.txt

PASO 1 - SUBIR
--------------
Copiá comunicacion.html a la raíz de GESBASE-WEB.
Copiá firebase-messaging-sw.js a la raíz de GESBASE-WEB.
Creá la carpeta sonidos si querés sonidos para primer plano.

PASO 2 - FIREBASE CONFIG
------------------------
Abrí Js/firebase-config.js y copiá esos mismos valores dentro de
firebase-messaging-sw.js.

PASO 3 - VAPID
--------------
En Firebase Console:
Project settings -> Cloud Messaging -> Web configuration
-> Web Push certificates -> Key pair.

Copiá la clave pública VAPID y reemplazá:
PEGAR_AQUI_LA_CLAVE_VAPID_DE_FIREBASE

PASO 4 - FUNCIÓN
----------------
Integrá functions-comunicacion.js en functions/index.js.
No reemplaces el index.js completo si ya tenés otras funciones.
Luego desplegá:
firebase deploy --only functions

PASO 5 - INDEX
--------------
El botón Comunicación debe apuntar a:
comunicacion.html

PASO 6 - SEGURIDAD
------------------
La interfaz ya restringe los contactos por empresaId.
Para producción también conviene agregar reglas Firestore que impidan
leer/escribir conversaciones de otra empresa. Eso es imprescindible.

IMPORTANTE SOBRE LLAMADAS FUERA DE LA SECCIÓN
----------------------------------------------
El sistema de notificaciones está separado de comunicacion.html.
Por eso la próxima etapa puede avisar de una llamada mientras el usuario
está en fichaje, presupuestos, trabajos u otra sección.

Una llamada web completamente fiable incluso con el navegador cerrado
requiere además WebRTC + TURN y una estrategia de notificación/llamada
compatible con Android. No se debe prometer que un navegador móvil se
comporte exactamente como WhatsApp.

PRÓXIMA ETAPA
-------------
1. llamada.html
2. videollamada.html
3. salas grupales
4. aceptar/rechazar llamada
5. colgar
6. micrófono/cámara
7. participantes
8. WebRTC + servidor TURN
9. notificación específica de llamada
