/*
 * PEGAR ESTE BLOQUE EN functions/index.js
 *
 * Requiere Firebase Functions v2 + firebase-admin.
 * No reemplaces tu archivo completo: integralo con tus funciones existentes.
 */

const { onDocumentCreated } = require("firebase-functions/v2/firestore");
const admin = require("firebase-admin");

// Si tu index.js YA tiene admin.initializeApp(), NO lo repitas.
// Si no lo tiene, agregá:
// admin.initializeApp();

exports.enviarNotificacionMensaje = onDocumentCreated(
  "conversaciones/{conversationId}/mensajes/{messageId}",
  async (event) => {
    const snap = event.data;
    if (!snap) return;

    const msg = snap.data();
    if (!msg || !msg.receiverUid || !msg.empresaId) return;

    const tokenRef = admin.firestore()
      .collection("tokensNotificaciones")
      .doc(msg.receiverUid);

    const tokenSnap = await tokenRef.get();
    if (!tokenSnap.exists) return;

    const tokenData = tokenSnap.data();

    // Seguridad: el token debe pertenecer a la misma empresa.
    if (tokenData.empresaId !== msg.empresaId) return;

    const token = tokenData.token;
    if (!token) return;

    const response = await admin.messaging().send({
      token,
      notification: {
        title: msg.senderName || "GESBASE",
        body: msg.text || "Nuevo mensaje"
      },
      data: {
        url: "/GESBASE-WEB/comunicacion.html",
        type: "mensaje",
        empresaId: String(msg.empresaId),
        senderUid: String(msg.senderUid || "")
      }
    });

    return response;
  }
);
